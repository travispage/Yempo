<?php
  if (!defined('WP_SITE_URL')) {
    define('WP_SITE_URL' , 'http://www.wishpond.com');
  }

  if (!defined('WP_SECURE_SITE_URL')) {
    define('WP_SECURE_SITE_URL' , 'https://www.wishpond.com');
  }
?>
