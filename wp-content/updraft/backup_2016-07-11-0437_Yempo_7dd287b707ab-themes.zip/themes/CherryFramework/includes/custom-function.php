<?php
	// Other theme functions
?>